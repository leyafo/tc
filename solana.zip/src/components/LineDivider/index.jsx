import React from "react";
import "./index.scss";

function LineDivider() {
  return <div className="line-divider"></div>;
}

export default LineDivider;
