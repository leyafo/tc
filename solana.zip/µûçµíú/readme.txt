蓝湖UI：
https://lanhuapp.com/url/xHUeL-AUrGjv

产品原型：
https://modao.cc/app/NTR4DbPPrfbei6rSlWYflg


预览地址：
http://frontend.legenddigital.com.au/fisher/hyperpay-earn/#/




接口文档：
earn banner: https://api.legenddigital.com.au/project/17/interface/api/9428
earn 列表：https://api.legenddigital.com.au/project/17/interface/api/9412
earn 详情：https://api.legenddigital.com.au/project/17/interface/api/9420

《对接文档1.0 & 含依赖生态能力的介绍》
https://www.yuque.com/docs/share/80c9e554-4588-4693-b5d2-4b26582f5484?#



